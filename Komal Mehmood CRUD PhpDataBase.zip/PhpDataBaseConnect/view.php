<?php

include 'views/header.php';
include 'Connection.php';
$id  = $_REQUEST['page_id'];
$edit = "SELECT * FROM pages WHERE page_id= $id";

$result = mysqli_query($connect , $edit);
// all data is in this row now
$row = mysqli_fetch_assoc($result);

?>
<div class="container">

  <h1><?php echo $row['page_title']; ?> </h1>
  <p><?php echo $row['page_descrtiption']; ?></p>
</div>

<?php
include 'views/footer.php';


 ?>
