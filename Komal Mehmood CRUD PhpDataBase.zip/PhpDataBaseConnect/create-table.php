<?php


include 'Connection.php';

// varible             pages is my table name
$pages = "CREATE TABLE IF NOT EXISTS pages(

/* These are my column name and all attributes of database */

  page_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

  page_title VARCHAR(30)  NOT NULL,

  page_descrtiption TEXT

  )";

  if(mysqli_query($connect , $pages)){
echo "DataBase Table Created sucessfully or Exists Before";
  }else {
echo "there is an error creating table";
  }




 ?>
