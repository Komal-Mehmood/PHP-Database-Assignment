<?php
include 'views/header.php';
?>

<div class="container">

<form action="create-page.php" method="post">

  <div class="form-group" >
    <label for="pgae_id">Page Title</label>
    <input type="text" name="page-title" class="form-control" id="Page_Title">
  </div>

  <div class="form-group">
    <label for="pgae_desc">Page Descrtiption</label>
    <textarea type="text" name="page-descrtiption" class="form-control" id="Page_desc"></textarea>
  </div>

  <button type="submit" class="btn btn-primary">Save Data</button>

</form>
</div>


<?php
include 'views/footer.php'

 ?>
