<?php

include 'header.php';
include '../loop.php';






include 'footer.php';
?>
