<?php

include 'views/header.php';

include 'Connection.php';


$id = $_REQUEST['page_id'];

$edit = "SELECT * FROM pages WHERE page_id= $id";

$result = mysqli_query($connect , $edit);
// all data is in this row now
$row = mysqli_fetch_assoc($result);


if(isset($_POST['update'])){
  $pagetitle = $_POST['page-title'];

  $pagedes = $_POST['page-descrtiption'];

$update = "UPDATE pages SET page_title = '$pagetitle' , page_descrtiption = '$pagedes' WHERE page_id = $id";

if(mysqli_query($connect, $update)){
//echo "data updated";
}
else {
  echo "Eror";
}

}



?>
<div class="container">

<form action="" method="post">

  <div class="form-group" >
    <label for="pgae_title">Page Title</label>                                              <?php //databse col name ?>
    <input type="text" name="page-title" class="form-control" id="Page_Title" value="<?php echo $row['page_title']; ?>">
  </div>

  <div class="form-group">
    <label for="pgae_desc">Page Descrtiption</label>                                                     <?php // databse col name ?>
    <textarea type="text" name="page-descrtiption" class="form-control" id="Page_desc"><?php echo $row['page_descrtiption']; ?></textarea>

  </div>

  <button type="submit" class="btn btn-primary" name = "update">Update</button>

</form>
</div>

<?php

include 'views/footer.php';

 ?>
