<?php
include 'Connection.php';

// query in allpages varible
$allPages = "SELECT * FROM pages";

// run query and store data in result variable
$result = mysqli_query($connect , $allPages);
// to check result is not empty
if(mysqli_num_rows($result) > 0){

?>
<div class="container">

  <table class="table table-bordered">

  <thead>
     <tr>
       <th scope="col">Page id</th>
       <th scope="col">Page Title</th>
       <th scope="col">Page Descrtiption</th>
      <th scope="col">Action</th>
     </tr>
   </thead>

   <tbody>
<?php
// if result is not null or 0 then we will get data through loop
while ($row = mysqli_fetch_assoc($result)) {

?>




     <tr>
       <th scope="row"><?php echo $row['page_id']; ?></th>
       <td><?php echo $row['page_title']; ?></td>
       <td><?php echo $row['page_descrtiption']; ?></td>
       <td><button class="btn btn-primary">Edit</button>   <button class="btn btn-danger">Delete</button> </td>

     </tr>


<?php
// this php is just to remember whats happening
/*
  // $row['database column name']
echo 'ID : ' .$row["page_id"]. ' Page Tittle : ' .$row["page_title"]. ' Pgae Descrtiption ' .$row["page_descrtiption"];
*/
?>


<?php
}
?>



<?php
}
else {
  echo "Error";
}

?>

  </tbody>
  </table>
</div>
