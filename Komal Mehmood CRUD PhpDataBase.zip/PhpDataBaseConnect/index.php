

<?php

include 'views/header.php';
 ?>

This is My Home Page

<?php

include 'views/footer.php';
 ?>
