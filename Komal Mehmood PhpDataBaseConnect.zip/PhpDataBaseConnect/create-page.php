<?php

include 'views/header.php';

include 'Connection.php';


$pagetitle = $_POST['page-title'];

$pagedes = $_POST['page-descrtiption'];

$insert = "INSERT INTO pages (page_title,page_descrtiption) VALUES ('$pagetitle' ,'$pagedes')";


if(mysqli_query($connect , $insert)){
echo "Data Inserted";
}else {
echo "The Data is not inserted please see again";
}




 include 'views/footer.php';
  ?>
